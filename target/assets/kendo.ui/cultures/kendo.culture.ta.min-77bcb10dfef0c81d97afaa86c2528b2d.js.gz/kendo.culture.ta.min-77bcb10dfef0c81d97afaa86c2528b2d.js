/*
* Kendo UI Complete v2014.1.318 (http://kendoui.com)
* Copyright 2014 Telerik AD. All rights reserved.
*
* Kendo UI Complete commercial licenses may be obtained at
* http://www.telerik.com/purchase/license-agreement/kendo-ui-complete
* If you do not own a commercial license, this file shall be governed by the trial license terms.
*/
!function(e,define){define([],e)}(function(){return function(e){var t=e.kendo||(e.kendo={cultures:{}});t.cultures.ta={name:"ta",numberFormat:{pattern:["-n"],decimals:2,",":",",".":".",groupSize:[3,2],percent:{pattern:["-n %","n %"],decimals:2,",":",",".":".",groupSize:[3,2],symbol:"%"},currency:{pattern:["$ -n","$ n"],decimals:2,",":",",".":".",groupSize:[3,2],symbol:"ரூ"}},calendars:{standard:{days:{names:["ஞாயிற்றுக்கிழமை","திங்கள்கிழமை","செவ்வாய்கிழமை","புதன்கிழமை","வியாழக்கிழமை","வெள்ளிக்கிழமை","சனிக்கிழமை"],namesAbbr:["ஞாயிறு","திங்கள்","செவ்வாய்","புதன்","வியாழன்","வெள்ளி","சனி"],namesShort:["ஞா","தி","செ","பு","வி","வெ","ச"]},months:{names:["ஜனவரி","பிப்ரவரி","மார்ச்","ஏப்ரல்","மே","ஜூன்","ஜூலை","ஆகஸ்ட்","செப்டம்பர்","அக்டோபர்","நவம்பர்","டிசம்பர்",""],namesAbbr:["ஜனவரி","பிப்ரவரி","மார்ச்","ஏப்ரல்","மே","ஜூன்","ஜூலை","ஆகஸ்ட்","செப்டம்பர்","அக்டோபர்","நவம்பர்","டிசம்பர்",""]},AM:["காலை","காலை","காலை"],PM:["மாலை","மாலை","மாலை"],patterns:{d:"dd-MM-yyyy",D:"dd MMMM yyyy",F:"dd MMMM yyyy HH:mm:ss",g:"dd-MM-yyyy HH:mm",G:"dd-MM-yyyy HH:mm:ss",m:"dd MMMM",M:"dd MMMM",s:"yyyy'-'MM'-'dd'T'HH':'mm':'ss",t:"HH:mm",T:"HH:mm:ss",u:"yyyy'-'MM'-'dd HH':'mm':'ss'Z'",y:"MMMM yyyy",Y:"MMMM yyyy"},"/":"-",":":":",firstDay:1}}}}(this),window.kendo},"function"==typeof define&&define.amd?define:function(e,t){t()});
